public class Book {

    private String itemNo;
    private String title;
    private String author;

    /**
     * @param itemNo Book number
     * @param title Book title
     * @param author Book author
     */
    public Book(String itemNo,String title,String author){
        this.itemNo = itemNo;
        this.title = title;
        this.author = author;
    }

    public Book() {

    }


    /**
     * set the new value of
     * @param itemNo update book number
     */
    public void setItemNo(String itemNo) {
        this.itemNo = itemNo;
    }

    /**
     * @param title updates new title
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @param writer updates new writer
     */
    public void setAuthor(String writer) {
        this.author = writer;
    }

    /**
     * @return book number
     */
    public String getItemNo() {
        return itemNo;
    }

    /**
     * @return  output to be display
     */
    @Override
    public String toString() {
        return  "Book info ----\n" +
                "Book Number:"+ this.itemNo + "\n"+
                "Title: " + this.title + "\n" +
                "Author: " + this.author + "\n" +
                "---------------\n";
    }
}
