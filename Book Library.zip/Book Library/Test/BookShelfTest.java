
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.*;

public class BookShelfTest {
    @Test
    public void checkingIfTheArrayIsEmpty(){
        ArrayList<Book> listOfBooks= new ArrayList<>();
        assertEquals(0,listOfBooks.size());

    }
    @Test
    public void addToEmptyArray(){
        ArrayList<Book> listOfBooks= new ArrayList<>();
        listOfBooks.add(new Book("1","Trials of Apollo","Rick Riordan"));
        assertEquals(1,listOfBooks.size());
    }

    @Test
    public void addMoreBooksToArray(){
        ArrayList<Book> listOfBooks= new ArrayList<>();
        listOfBooks.add(new Book("1","Trials of Apollo","Rick Riordan"));
        listOfBooks.add(new Book("2","Trials of Apollo","Rick Riordan"));
        assertEquals(2,listOfBooks.size());
    }

    @Test
    public void removeBookFromArray(){
        ArrayList<Book> listOfBooks= new ArrayList<>();
        listOfBooks.add(new Book("1","Trials of Apollo","Rick Riordan"));
        listOfBooks.add(new Book("2","Trials of Apollo","Rick Riordan"));

        listOfBooks.remove(0);
        assertEquals(1,listOfBooks.size());
    }

    @Test
    public void removeAllBooksFromArray(){
        ArrayList<Book> listOfBooks= new ArrayList<>();
        listOfBooks.add(new Book("1","Trials of Apollo","Rick Riordan"));
        listOfBooks.add(new Book("2","Trials of Apollo","Rick Riordan"));

        listOfBooks.clear();
        assertEquals(0,listOfBooks.size());
    }

}