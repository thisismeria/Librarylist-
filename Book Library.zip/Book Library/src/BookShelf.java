/**
 * This is a Bookshelf that will hold a list of
 * books with its author
 *
 * @author Ria Ann De la Cruz
 * @version 1.0
 * @since 01-14-20
 */
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class BookShelf {
    static int choice;

    ArrayList<Book> listOfBooks = new ArrayList<Book>();

    static Scanner choiceInput = new Scanner(System.in);
    Scanner scan = new Scanner(System.in);

    /**
     *This class method display the list of
     * choices the user can do in this program.
     * the @param choice takes the user's input
     */
    private void displayMenu() {
        System.out.println(">########################################################################");
        System.out.println("> Choose one of the options below by typing the corresponding number: ");
        System.out.println(">====================================================================");
        System.out.println("1- Check library list.");
        System.out.println("2- Add a book to the Library.");
        System.out.println("3- Delete a book.");
        System.out.println("4- Blow up library.");
        System.out.println("5- Back to main menu.");
        System.out.println("0- Exit.");
        System.out.println(">########################################################################");
        System.out.println("> Enter your option here: ");
        choice = choiceInput.nextInt();
    }


    /**
     * This class sets the user input to the Object
     * Book which holds as the builder of the
     * arraylist listOfBooks
     */
    public void createBook(){

        Book newBook = new Book();

            System.out.println("Enter Book Number:");
            newBook.setItemNo(scan.nextLine());

            System.out.println("Enter Title:");
            newBook.setTitle(scan.nextLine());

            System.out.println("Enter writer's name:");
            newBook.setAuthor(scan.nextLine());

            listOfBooks.add(newBook);

    }


    /**
     * Print out @param s for every list on
     * the array
     */
    private void displayBookShelf() {
        for (Book s: listOfBooks) {
            System.out.print( s.toString() );
        }


    }

    /**
     * Check if the item on the list is same with
     * the @param bookToRemove that holds the user input
     */
    private void removeBook() {
        System.out.println("Book number to be removed:");
        String bookToRemove= scan.nextLine();
        // checking every object on the array using its index if it is equal to user's input
        for (int i=0; i<listOfBooks.size(); i++) {
            if (listOfBooks.get(i).getItemNo().equals(bookToRemove)){
                listOfBooks.remove(i);
                break;
            }
        }
    }

    /**
     * Delete all item on the list
     */
    public void emptyLibrary() {
        System.out.println("> WARNING < You have chosen to delete all books in the library! ");
        System.out.println("> Are you sure?? Enter 'yes' or 'no': ");
        String confirmation = scan.nextLine();
        try {
            if (confirmation.equalsIgnoreCase("yes")) {
                System.out.println("> Library is being deleted...");
                listOfBooks.clear();
                System.out.println("> Library is Empty!");
                choice = 5;
            }
        } catch (InputMismatchException error) {
            System.out.println("<ERROR> Make sure you spell yes or no correctly: ");
            choice = 4;
        }
    }

    /**
     * Run the whole program
     */
    public void choices(){
        
        displayMenu();//Displays the main menu and ask for choice.

        exit:

        while(choice != 0){
            try{
//Choice 1:
                if(choice == 1 && listOfBooks.size() > 0){

                    displayBookShelf();
                    choice =5;
                }

                if(choice == 1 && listOfBooks.size() == 0){
                    System.out.println("<ERROR> Library is empty! Please add a Book first!");
                    choice = 5;
                }
//Choice 2:
                if(choice == 2){
                    createBook();
                    displayMenu();
                }
//Choice 3:
                if(choice == 3){
                    removeBook();
                    try{
                        if(listOfBooks.size() > 0){
                            displayMenu();
                        }
                    }catch(IndexOutOfBoundsException error){
                        System.out.println("<ERROR> The array is Empty! Please add a book first!");
                        choice = 5;
                        //break; //Test the Break statement!!!!!!!!!!!!!!!!!!!
                    }
                }

//Choice 4:
                if(choice == 4) {
                    emptyLibrary();
                }
//Choice 5:
                if(choice ==5){
                    if(listOfBooks.size() > 0||listOfBooks.size() == 0){
                        displayMenu();
                    }
                }
//Choice 0:
                if(choice == 0){
                    break exit;
                }
            }catch(InputMismatchException error){
                System.out.println("@TEST@ <<< 5- Breaking from main while loop... >>>>");
                break exit;
            }

        }//end of while loop.


    }

    /**
     * This is the main method which make used of the
     * choice method
     * @param args Unused
     */
    public static void main(String[] args) {
        System.out.println("Hello, I am a bookshelf, enter your book's information!");

        BookShelf newBook = new BookShelf();
        newBook.choices();
    }
}
